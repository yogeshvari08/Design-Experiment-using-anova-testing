library(readxl)
locationstep <- read_excel("E:/R/ISEN 616/Project/Data.xlsx")
library(olsrr)
library(faraway)
#Step - 1
#factor l
m1 <- lm(y_bar ~ l+lw+lL+lW+ld+lF, data = locationstep)
ols_step_both_p(m1)

#factor w

m2 <- lm(y_bar ~ w+wL+wW+wd+wF+lw, data = locationstep)
ols_step_both_p(m2)

#factor L
m3 <- lm(y_bar ~ L+LW+Ld+LF+wL+lL, data = locationstep)
ols_step_both_p(m3)

#factor W 
m4 = lm(y_bar~W+Wd+WF+LW+wW+lW ,data=locationstep) 
ols_step_both_p(m4)

#factor d
m5 = lm(y_bar~d+dF+Wd+Ld+wd+ld ,data=locationstep) 
ols_step_both_p(m5)

#factor F
m6 = lm(y_bar~ F+dF+WF+LF+wF+lF ,data=locationstep) 
ols_step_both_p(m6)

#step 2
m7 = lm(y_bar~l+w+L+W+d+F+WF+LW ,data=locationstep) 
ols_step_both_p(m7)

#step 3
m8 = lm(y_bar~WF+LW ,data=locationstep) 
ols_step_both_p(m8)

#step 4
m9 = lm(y_bar~l+w+L+W+d+F+ WF+LW ,data=locationstep) 
ols_step_both_p(m9)


mfinal = lm(y_bar ~ WF+LW, data = locationstep)
summary(mfinal)

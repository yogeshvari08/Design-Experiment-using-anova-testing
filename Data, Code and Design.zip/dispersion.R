library(readxl)
locationstep <- read_excel("E:/R/ISEN 616/Project/Data.xlsx")
library(olsrr)
library(faraway)
#Step - 1
#factor l
m1 <- lm(lnS2 ~ l+lw+lL+lW+ld+lF, data = locationstep)
ols_step_both_p(m1)
#factor w
m2 <- lm(lnS2 ~ w+wL+wW+wd+wF+lw, data = locationstep)
ols_step_both_p(m2)
#factor L
m3 <- lm(lnS2 ~ L+LW+Ld+LF+wL+lL, data = locationstep)
ols_step_both_p(m3)
#factor W 
m4 = lm(lnS2~W+Wd+WF+LW+wW+lW ,data=locationstep) 
ols_step_both_p(m4)
#factor d
m5 = lm(lnS2~d+dF+Wd+Ld+wd+ld ,data=locationstep) 
ols_step_both_p(m5)
#factor F
m6 = lm(lnS2~ F+dF+WF+LF+wF+lF ,data=locationstep) 
ols_step_both_p(m6)
#step 2
m7 = lm(lnS2 ~ lF+wW+lW+lL+d+l+L+w+W+F, data = locationstep)
ols_step_both_p(m7)

#step 3
m8 = lm(lnS2 ~ wW+lF+lW+F+d+wd+Wd+dF+Ld+ld+WF+wF+LF, data = locationstep)
ols_step_both_p(m8)

#step 4
m9 = lm(lnS2 ~ wW+lF+lW+Ld+d+F+w+W+l+L, data = locationstep)
ols_step_both_p(m9, pent = 0.075, prem = 0.1)

m10 = lm(lnS2 ~ wW+lF+lW+d+dF+Wd+Ld+wd+ld + F+WF+LF+wF, data = locationstep)
ols_step_both_p(m10, pent = 0.075, prem = 0.1)

mfinal = lm(lnS2 ~ wW+lF+lW+d+F, data = locationstep)
summary(mfinal)





library(readxl)
locationstep <- read_excel("E:/R/ISEN 616/Project/Data.xlsx")
loc <- lm(y_bar ~ l+w+L+W+d+F+G+H+I+J+K, data = locationstep)
round(2*loc$coefficients, 5)
library(FrF2)
DanielPlot(loc, half=TRUE,autolab=F, 
main="Half Normal Plot of Location Effects for Paper Helicopter Experiment")
loc_reg <- lm(y_bar ~ w +d, data = locationstep)
summary(loc_reg)

dis <- lm(lnS2 ~ l+w+L+W+d+F+G+H+I+J+K, data = locationstep)
round(2*dis$coefficients, 5)
library(FrF2)
DanielPlot(dis, half=TRUE, autolab=F, 
main="Half Normal Plot of Dispersion Effects for Paper Helicopter Experiment")
dis_reg <- lm(lnS2 ~ L +d, data = locationstep)
summary(dis_reg)

